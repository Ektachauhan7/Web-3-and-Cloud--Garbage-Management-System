const WasteManagement = artifacts.require("WasteManagement");

module.exports = function (deployer) {
    deployer.deploy(WasteManagement);
};

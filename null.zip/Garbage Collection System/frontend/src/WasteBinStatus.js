// // WasteBinStatus.js
// import React, { useState, useEffect } from 'react';

// const WasteBinStatus = ({ binId }) => {
//     const [fillLevel, setFillLevel] = useState(0);

//     useEffect(() => {
//         // Fetch fill level data from blockchain or IoT simulator
//         const fetchFillLevel = async () => {
//             // Your code to fetch fill level data
//             // Example: const fillLevelData = await fetchFillLevelFromBlockchain(binId);
//             // Example: setFillLevel(fillLevelData);
//         };
//         fetchFillLevel();
//     }, [binId]);

//     return (
//         <div>
//             <h3>Waste Bin {binId}</h3>
//             <p>Fill Level: {fillLevel}</p>
//         </div>
//     );
// };

// export default WasteBinStatus;

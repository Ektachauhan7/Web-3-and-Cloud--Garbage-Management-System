import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Garbagebins from './components/Garbagebins';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import BinsPage from './components/BinsPage';



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(

    <React.StrictMode>
        <Router>
            <Routes>
                <Route path="/binspage" element={<BinsPage />} />
                <Route path="/garbage" element={<Garbagebins />} />
                <Route path="/" element={<App />} />
            </Routes>
        </Router>
    </React.StrictMode>
);


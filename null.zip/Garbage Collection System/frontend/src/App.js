import './App.css';
import React, { useEffect } from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { getAccountBalance, registerContractor } from './connect_blockchain';

const App = () => {
  const [inputValue, setInputValue] = useState('');
  const [balance, setBalance] = useState('');

  useEffect(() => {
    const getBalance = async () => {
      const address = localStorage.getItem('contractor_address')
      if (address) {
        const bal = await getAccountBalance(address);
        setBalance(bal);
      }
    }
    getBalance();
  });

  const registerC = () => {
    registerContractor(inputValue);
  };


  const handleChange = (event) => {
    setInputValue(event.target.value);
  };

  return (
    <>
      <div className='header text'>
        <div>Waste Managment System</div>
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <span>Balance : {balance}</span>
          <img src='/trashbin.png' className='icon' alt='img'></img>
        </div>
      </div>

      <div className="container textS">
        <div className="card ">
          <h2>Register As Contractor</h2>
          <img src='/collector.png' alt='' className='icon2 '></img>
          <div>
            <input
              type="text"
              value={inputValue}
              onChange={handleChange}
            />
          </div>
          <Link to="/">

            <button onClick={registerC}>Register</button>
          </Link>
        </div>
        <div className="card">
          <h2>Show Garbage Bins</h2>
          <img src='/trashbin.png' alt='' className='icon2'></img>
          <Link to="/binspage">
            <button>Show Trashbins</button>
          </Link>

        </div>
      </div>



    </>
  );
};

export default App;

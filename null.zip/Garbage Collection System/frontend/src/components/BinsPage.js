import React, { useEffect, useState } from 'react';
import Garbagebins from './Garbagebins';
import { getAccountBalance, getAllDustbins } from '../connect_blockchain';

const BinsPage = () => {
  const [binsData, setBinData] = useState([]);

  const [balance, setBalance] = useState('');

  useEffect(() => {
    const getBalance = async () => {
      const address = localStorage.getItem('contractor_address')
      if (address) {
        const bal = await getAccountBalance(address);
        setBalance(bal);
      }
    }
    getBalance();
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllDustbins();
        setBinData(data);
      } catch (error) {
        console.error('Error fetching dustbins:', error);
      }
    };

    fetchData();
  }, []);


  return (
    <>
      <div className='header text'>
        <div>Waste Managment System</div>
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <span>Balance : {balance}</span>
          <img src='/trashbin.png' className='icon' alt='img'></img>
        </div>
      </div>

      {localStorage.getItem('contractor_address') == null && <h3 className='address' style={{ marginLeft: '20px' }} >Please register as a contractor to pick a dustbin</h3 >}
      <div className="grid-container">
        {binsData?.map((bin) => (
          <Garbagebins
            key={bin.id}
            id={bin.id}
            name={bin.name}
            percentageFull={bin.fillPercentage}
            contractor={bin.contractor}
          />
        ))}
      </div>

    </>
  );
};

export default BinsPage;
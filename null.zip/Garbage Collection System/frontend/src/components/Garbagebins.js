import React from 'react';
import { pickDustbin } from '../connect_blockchain';

const Garbagebins = ({ id, name, percentageFull, contractor }) => {
    const percentageStyles = {
        width: `${percentageFull}%`,
        height: '20px',
        backgroundColor: '#4CAF50',
        borderRadius: '10px'
    };
    const percentageStyles2 = {
        width: `${percentageFull}%`,
        height: '20px',
        backgroundColor: 'red',
        borderRadius: '10px'
    };

    const click = () => {
        const address = localStorage.getItem('contractor_address');
        if (address) {
            pickDustbin(id, address);
            // window.location.reload();
        }
        else {
            alert('Please register as contractor first');
        }
    }

    const IsPickDisabled = () => {
        let disabled = false;
        if (localStorage.getItem('contractor_address') == null) {
            disabled = true;
        }
        if (percentageFull < 80) {
            disabled = true;
        }
        if (contractor != '0x0000000000000000000000000000000000000000') {
            disabled = true;
        }
        return disabled;
    }
    return (
        <div className='grid'>
            <div className="bin-card">
                <div className="bin-number">Bin Number: {id}</div>
                <div className="address">Name:{name}</div>
                <div className="percentage-bar">
                    <div className="percentage-fill" style={percentageFull < 80 ? percentageStyles : percentageStyles2}></div>
                </div>
                <div className="percentage-text">Capacity Consumed: {percentageFull}%</div>
                <button className='margin'
                    disabled={IsPickDisabled()} onClick={click}>Pick Dustbin</button>
                <div className='address'>Contractor : {contractor !== '0x0000000000000000000000000000000000000000' && contractor}</div>
            </div>
        </div>
    );
};

export default Garbagebins;

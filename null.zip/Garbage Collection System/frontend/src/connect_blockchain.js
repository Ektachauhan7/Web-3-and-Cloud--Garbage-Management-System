// bin_simulator.js
const { Web3 } = require('web3');
const web3 = new Web3('http://127.0.0.1:9545');
const { abi } = require('./abi/waste_management.json');

const contractAddress = '0xc44A77cA13D522777C4CA72EAb17df52D42993D9';
const contract = new web3.eth.Contract(abi, contractAddress);

export const createDustbin = async (name, percentage) => {
    try {
        const accounts = await web3.eth.getAccounts();
        const userAccount = accounts[0]; // Assuming you want to use the first account
        await contract.methods.addDustbin(name, percentage).send({ from: userAccount, gas: 300000 });
        console.log(`Dustbin "${name}" created successfully.`);
    } catch (error) {
        console.error(`Error creating dustbin: ${error.message}`);
    }
};

export const getAllDustbins = async () => {
    const data = await contract.methods.getAllDustbins().call();
    return data.map((item) => {
        return {
            name: item.name,
            contractor: item.contractor,
            id: item.id.toString(),
            fillPercentage: item.fillPercentage.toString()
        }
    })
}

async function addressExists(address) {
    try {
        const txCount = await web3.eth.getTransactionCount(address);
        return txCount > 0;
    } catch (error) {
        console.error('Error:', error);
        return false;
    }
}

export async function registerContractor(contractorAddress) {
    try {
        console.log(contractorAddress);
        if (addressExists(contractorAddress)) {

            // await contract.methods.registerContractor.call(contractorAddress)
            //     .then(() => {
            //         const tx = contract.methods.registerContractor().send({ from: contractorAddress })
            //         console.log('Contractor registered successfully. Transaction hash:', tx.transactionHash);
            //         localStorage.setItem('contractor_address', contractorAddress);
            //         alert('user registered successfully');

            //     }).catch(err => {
            //         throw err;
            //     }
            //     )

            await contract.methods.registerContractor.call(contractorAddress);
            const tx = await contract.methods.registerContractor().send({ from: contractorAddress });
            console.log('Contractor registered successfully. Transaction hash:', tx.transactionHash);
            localStorage.setItem('contractor_address', contractorAddress);
            alert('user registered successfully');


        }
        else {
            console.log("addressExists", false);
            alert('Invalid Address');
        }

    } catch (error) {
        console.log(error);
        alert('Invalid Address');
    }
}

export const pickDustbin = async (dustbinId, contractorId) => {
    contract.methods.pickDustbin(dustbinId).send({ from: contractorId, gas: 300000 })
        .then(receipt => {
            console.log('Transaction Receipt:', receipt);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}



export async function getDustbinById(id) {
    try {
        const dustbin = await contract.methods.getDustbinById(id).call();
        console.log('Dustbin Details:', dustbin);
    } catch (error) {
        console.error('Error:', error);
    }
}

export async function updateFillPercentage(id, newFillPercentage) {
    try {
        const accounts = await web3.eth.getAccounts();
        const userAccount = accounts[0];
        const receipt = await contract.methods.updateFillPercentage(id, newFillPercentage).send({ from: userAccount, gas: 300000 });
        console.log('Transaction Receipt:', receipt);
    } catch (error) {
        console.error('Error:', error);
    }
}


export const emptyDustbin = async (dustbinId, contractorAddress) => {
    contract.methods.emptyDustbin(dustbinId).send({ from: contractorAddress, gas: 500000 })
        .then(receipt => {
            console.log('Transaction Receipt:', receipt);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

export const getAccountBalance = async (address) => {
    try {
        const balance = await web3.eth.getBalance(address);
        const balanceInEther = web3.utils.fromWei(balance, 'ether');
        console.log('Account Balance:', balanceInEther, 'ETH');
        return balanceInEther;

    }
    catch (error) {
        console.error('Error:', error);
    };
}

export async function getContractBalance() {
    const balance = await web3.eth.getBalance(contractAddress);
    console.log('Contract Balance:', web3.utils.fromWei(balance, 'ether'), 'ETH');
}



export async function transferEthersToContract(privateKey, amountInEth) {
    const account = web3.eth.accounts.privateKeyToAccount('0x' + privateKey);
    const amountInWei = web3.utils.toWei(amountInEth, 'ether');

    const tx = {
        from: account.address,
        to: contractAddress,
        value: amountInWei,
        gasPrice: '0x12a05f200',
    };

    tx.gas = web3.utils.toHex(80000);

    const signedTx = await web3.eth.accounts.signTransaction(tx, '0x' + privateKey);
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);

    console.log('Transaction Receipt:', receipt);
}








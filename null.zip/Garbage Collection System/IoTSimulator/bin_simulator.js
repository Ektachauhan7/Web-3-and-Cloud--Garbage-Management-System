const contractAddress = '0xc44A77cA13D522777C4CA72EAb17df52D42993D9';
const noOfBinsToCreate = 10;
const senderAccountForSmartContractPublicKey = "0xb992fc5c1bddd7314d214d8619c3e3cf8ef62165";
const senderAccountForSmartContractPrivateKey = "aab8538fb89c39530e01515447e4f7b92b38feecaa1812bea1b6b55d3395f5cb";


const { Web3 } = require('web3');
const web3 = new Web3('http://127.0.0.1:9545');
const { abi } = require('../blockchain/build/contracts/WasteManagement.json');

const contract = new web3.eth.Contract(abi, contractAddress);

const createDustbin = async (name, percentage) => {
    try {
        const accounts = await web3.eth.getAccounts();
        const userAccount = accounts[0];
        await contract.methods.addDustbin(name, percentage).send({ from: userAccount, gas: 300000 });
        console.log(`Dustbin "${name}" created successfully.`);
    } catch (error) {
        console.error(`Error creating dustbin: ${error.message}`);
    }
};

const getAllDustbins = async () => {
    const allDustbins = await contract.methods.getAllDustbins().call();
    // console.log(allDustbins);
    return allDustbins;
}

async function registerContractor(contractorAddress) {
    try {
        const tx = await contract.methods.registerContractor().send({ from: contractorAddress });
        console.log('Contractor registered successfully. Transaction hash:', tx.transactionHash);
    } catch (error) {
        console.error('Error:', error);
    }
}

const pickDustbin = async (dustbinId, contractorId) => {
    contract.methods.pickDustbin(dustbinId).send({ from: contractorId, gas: 300000 })
        .then(receipt => {
            console.log('Transaction Receipt:', receipt);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}



async function getDustbinById(id) {
    try {
        const dustbin = await contract.methods.getDustbinById(id).call();
        // console.log('Dustbin Details:', dustbin);
        return dustbin;
    } catch (error) {
        console.error('Error(getDustbinById):', error);
    }
}

async function updateFillPercentage(id, newFillPercentage) {
    try {
        const accounts = await web3.eth.getAccounts();
        const userAccount = accounts[0];
        const receipt = await contract.methods.updateFillPercentage(id, newFillPercentage).send({ from: userAccount, gas: 300000 });
        console.log('Transaction Receipt:', receipt);
    } catch (error) {
        console.error('Error:', error);
    }
}


const emptyDustbin = async (dustbinId, contractorAddress) => {
    contract.methods.emptyDustbin(dustbinId).send({ from: contractorAddress, gas: 500000 })
        .then(receipt => {
            console.log('Transaction Receipt:', receipt);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

const getAccountBalance = async (address) => {
    try {
        const balance = await web3.eth.getBalance(address);
        const balanceInEther = web3.utils.fromWei(balance, 'ether');
        console.log('Account Balance:', balanceInEther, 'ETH');
        return balanceInEther;

    }
    catch (error) {
        console.error('Error:', error);
    };
}

async function getContractBalance() {
    const balance = await web3.eth.getBalance(contractAddress);
    const balanceInEth = web3.utils.fromWei(balance, 'ether')
    console.log('Contract Balance:', balanceInEth, 'ETH');
    return balanceInEth;
}



async function transferEthersToContract(privateKey, amountInEth) {
    const account = web3.eth.accounts.privateKeyToAccount('0x' + privateKey);
    const amountInWei = web3.utils.toWei(amountInEth, 'ether');

    const tx = {
        from: account.address,
        to: contractAddress,
        value: amountInWei,
        gasPrice: '0x12a05f200',
    };

    tx.gas = web3.utils.toHex(80000);

    const signedTx = await web3.eth.accounts.signTransaction(tx, '0x' + privateKey);
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);

    console.log('Transaction Receipt:', receipt);
}


const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const Simulator = async () => {
    const accountBalance = await getAccountBalance(senderAccountForSmartContractPublicKey);
    const contractBalance = await getContractBalance();
    console.log(accountBalance, contractBalance)

    if (accountBalance > 51 && contractBalance <= 2) {
        await transferEthersToContract(senderAccountForSmartContractPrivateKey, '50');
    }

    const binsBeforeCreation = await getAllDustbins();
    if (binsBeforeCreation.length < noOfBinsToCreate) {
        for (let i = binsBeforeCreation.length; i < noOfBinsToCreate; i++) {
            await createDustbin(`Dustbin ${i}`, 0);
        }
    }


    const bins = await getAllDustbins();
    console.log(bins);
    while (true) {
        for (const bin of bins) {
            const binId = parseInt(bin.id.toString());
            const binData = await getDustbinById(binId);
            const fillPercentage = parseInt(binData.fillPercentage.toString());
            if (fillPercentage >= 100 && binData.contractor != '0x0000000000000000000000000000000000000000') {
                const newContractBalance = await getContractBalance();
                if (newContractBalance > 2) {
                    emptyDustbin(binId, binData.contractor);
                }
                else {
                    console.log('contract is low at balance');
                }
            }
            else if (fillPercentage < 100) {
                const randomNumber = Math.floor(Math.random() * 100 - fillPercentage) + 1;
                await updateFillPercentage(binId, fillPercentage + randomNumber);
            }
        }
        await delay(60000)
    }
}

Simulator();









